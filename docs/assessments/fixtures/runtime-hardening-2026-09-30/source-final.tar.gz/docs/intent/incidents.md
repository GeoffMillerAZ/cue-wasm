# Incidents

## 2026-09-30 — source checkout masked package/lifecycle gaps
Audit found omitted default engine assets and worker readiness advertised before
full evaluation, with no cancellation/disposal settlement. Existing tests did not
exercise an independently installed archive or actual browser lifecycle.
Outcome: package positive/negative smoke and worker lifecycle tests added; broader
source/binary provenance and semantic compatibility remain open in the tracker.
