# Decisions

| ID | Decision | Status | Revisit when |
|---|---|---|---|
| [0001](0001-authoritative-optional-runtime.md) | Official CUE, capability-selected disposable workers | Accepted | Measured consumer need justifies alternate host or split |
| [0002](0002-evidence-and-reproducibility.md) | Reproducible artifacts and behavior-specific support evidence | Accepted | Build/host model changes |

Next: 0003. Accepted architecture does not imply completed implementation.
