# Changelog

## [Unreleased]
Release impact: breaking worker lifecycle/return-contract correction; no release published.

### Breaking
- Worker initialization now resolves the selected engine or syntax-only reader;
  implicit reader-first/background-engine loading is removed.
- Worker getSymbols returns the same JSON string as direct API; Workspace parses it.
- Worker requests have finite input/queue/deadline limits; active cancellation
  terminates the owner and rejects queued work. Retry requires a fresh owner.

### Fixed
- Package includes default engine, reader and matching loader asset paths.
- Worker failures and disposal settle pending promises; initialization can be retried.
- Generated JavaScript/types have an explicit source and drift-check entry point.

### Added
- Deterministic lifecycle tests, independent archive smoke and actual browser fixture.
- Canonical intent/ADRs and current evidence-based hardening roadmap.
