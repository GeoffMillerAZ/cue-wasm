import test from 'node:test';
import assert from 'node:assert';
const { Workspace } = await import('../../internal/js/workspace.js');

test('Workspace Manager - TDD Suite', async (t) => {

    await t.test('should add files and generate a flat overlay for WASM', () => {
        const ws = new Workspace();
        ws.addFile('main.cue', 'import "foo:bar"\nres: bar.val');
        ws.addFile('pkg/foo/bar.cue', 'val: 42');

        const overlay = ws.getOverlay();
        
        assert.strictEqual(Object.keys(overlay).length, 2);
        // Workspace normalizes to leading slash
        assert.strictEqual(overlay['/main.cue'], 'import "foo:bar"\nres: bar.val');
        assert.strictEqual(overlay['/pkg/foo/bar.cue'], 'val: 42');
    });

    await t.test('should handle file updates correctly', () => {
        const ws = new Workspace();
        ws.addFile('test.cue', 'v: 1');
        ws.addFile('test.cue', 'v: 2'); // Update
        
        const overlay = ws.getOverlay();
        assert.strictEqual(overlay['/test.cue'], 'v: 2');
    });

    await t.test('should support removing files', () => {
        const ws = new Workspace();
        ws.addFile('a.cue', 'a: 1');
        ws.removeFile('a.cue');
        
        const overlay = ws.getOverlay();
        assert.strictEqual(overlay['/a.cue'], undefined);
    });

    await t.test('should throw error when adding invalid paths', () => {
        const ws = new Workspace();
        assert.throws(() => {
            ws.addFile('', 'content');
        }, /Invalid path/);
    });

    await t.test('INTEGRATION: should unify multiple files via Workspace and WASM', async () => {
        const { loadWasm } = await import('../../dist/index.js');
        const cue = await loadWasm();
        const ws = new Workspace();

        ws.addFile('a.cue', 'package test\nval: 41', true);
        ws.addFile('b.cue', 'package test\nres: val + 1', true);

        const overlay = ws.getOverlay();
        const entryPoints = ws.getEntryPoints();
        const result = await cue.unify(overlay, entryPoints);
        const json = JSON.parse(result);

        assert.strictEqual(json.res, 42);
        console.log("✅ Integration Test Passed: Workspace correctly prepared WASM inputs.");
    });

    await t.test('Fast Syntax Validation - should catch syntax errors instantly', async () => {
        const { loadWasm } = await import('../../dist/index.js');
        const cue = await loadWasm();
        
        // 1. Valid Syntax
        const validRes = await cue.parse('a: 1\nb: 2');
        assert(validRes.includes('a: 1'));
        console.log("✅ Valid syntax parsed successfully.");

        // 2. Invalid Syntax (Missing colon)
        try {
            await cue.parse('a 1');
            assert.fail("Should have caught syntax error");
        } catch (e) {
            // Log the error to see what Go returns
            console.log("Caught Syntax Error:", e);
            const err = JSON.parse(e);
            assert.strictEqual(err.line, 1);
            // The official CUE 0.12 error message might be different
            assert(err.message.length > 0);
            console.log("✅ Syntax error caught with line info.");
        }
    });

    await t.test('Automatic Formatting - should normalize code and preserve comments', async () => {
        const { loadWasm } = await import('../../dist/index.js');
        const cue = await loadWasm();
        const ws = new Workspace();

        const messyCode = `
        // Important comment
        a:   1
        b: 2    // Side comment
        `;

        ws.addFile('messy.cue', messyCode);
        const formatted = await ws.formatFile('messy.cue', cue);

        assert(formatted.includes('// Important comment'));
        assert(formatted.includes('a: 1')); // Whitespace collapsed
        assert(formatted.includes('b: 2 // Side comment'));
        console.log("✅ Formatting verified: preserved comments and cleaned whitespace.");
    });

    await t.test('Symbol Extraction - should identify fields and packages with positions', async () => {
        const { loadWasm } = await import('../../dist/index.js');
        const cue = await loadWasm();
        const ws = new Workspace();

        const code = `
        package config
        
        user: {
            name: "geoff"
        }
        version: 1.0
        `;

        ws.addFile('config.cue', code);
        const symbols = await ws.getSymbols('config.cue', cue);

        // Verify package
        const pkg = symbols.find(s => s.type === 'package');
        assert.strictEqual(pkg.name, 'config');

        // Verify top-level field
        const userField = symbols.find(s => s.name === 'user');
        assert.ok(userField, "Should find top-level 'user' field");

        // Verify nested field (This proves the recursive walk)
        const nameField = symbols.find(s => s.name === 'name');
        assert.ok(nameField, "Should find nested 'name' field");
        assert.strictEqual(nameField.line, 5);

        console.log("✅ Symbol extraction verified: found nested fields via recursive walk.");
    });
});